import React,{Component} from 'react';
import Header from './Header'
export default class App extends Component{
    constructor(){
        super();

        this.state={
            title:'XX官网商城'
        };
    }
    render(){
        return (<div>
            <Header title={this.state.title} />
        </div>)
    }
}