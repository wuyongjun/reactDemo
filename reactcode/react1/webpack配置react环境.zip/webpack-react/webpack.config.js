const HtmlWebpackPlugin = require('html-webpack-plugin');

module.exports = {
    entry:{
        entry:'./src/index.js'
    },
    output:{
        path:__dirname+'/dist',
        filename:'[name].bundle.js'
    },
    module:{
        rules:[
            {
                test:/\.js$/,
                use:['babel-loader'],
                exclude:/node_modules/
            }
        ]
    },
    devServer:{
        contentBase:__dirname+'/dist',
        host:'localhost',
        port:4000,
        open:true
    },
    plugins:[
        new HtmlWebpackPlugin({
            hash:true,
            template:'./public/index.html'
        })
    ]
};